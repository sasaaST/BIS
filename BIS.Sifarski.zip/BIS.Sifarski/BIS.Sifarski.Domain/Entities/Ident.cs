﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BIS.Sifarski.Domain.Entities
{
    public class Ident
    {
        public int Id { get; set; }
        public short BN000035 { get; set; }
        public string BN000036 { get; set; }
        public int BN000181 { get; set; }
        public int BN000182 { get; set; }
        public int BN000183 { get; set; }
        public int BN000184 { get; set; }
        public int BN000185 { get; set; }
        public char BN000250 { get; set; }
        public char BN000251 { get; set; }
        public string BN000379 { get; set; }
        public string BN000252 { get; set; }
        public short BN000260 { get; set; }
        public string BN000380 { get; set; }
        public string BN000243 { get; set; }
        public string BN000388 { get; set; }
        public char BN000576 { get; set; }
        public char BN000601 { get; set; }
        public string BN000639 { get; set; }
        public string BN000640 { get; set; }
        public string BND00089 { get; set; }
        public int BN000749 { get; set; }
        public int BN000750 { get; set; }
        public string BN000002 { get; set; }
        public int BND00011 { get; set; }
        public int BNDC0265 { get; set; }
        public short BN001055 { get; set; }
    }
}
