﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BIS.Sifarski.Domain.Entities
{
    public class IdentCh
    {
        public short BN000035 { get; set; }
        public string BN000036 { get; set; }
        public short BN000071 { get; set; }
        public short BN000073 { get; set; }
        public int BN000181 { get; set; }
        public int BN000391 { get; set; }
        public double BN000392 { get; set; }
        public string BN000393 { get; set; }
        public int Id { get; set; }
    }
}
