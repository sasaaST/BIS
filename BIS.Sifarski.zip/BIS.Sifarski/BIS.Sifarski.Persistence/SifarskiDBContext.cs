﻿using BIS.Sifarski.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using System;

namespace BIS.Sifarski.Persistence
{
    public class SifarskiDbContext : DbContext
    {
        public SifarskiDbContext(DbContextOptions<SifarskiDbContext> options) : base(options)
        {
        }

        public DbSet<Ident> Idents { get; set; }
        public DbSet<IdentCh> IdentChs { get; set; }
    }
}
