﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BIS.Sifarski.Domain.Entities;
using BIS.Sifarski.Persistence;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BIS.Sifarski.API.Controllers
{
    [Route("api/[controller]")]
    public class IdentChController : Controller
    {
        private readonly SifarskiDbContext _context;

        public IdentChController(SifarskiDbContext context)
        {
            _context = context;

            if (_context.IdentChs.Count() == 0)
            {
                _context.IdentChs.Add(new IdentCh { BN000035 = 100, BN000036 = "111", BN000071 = 1, BN000073 = 2, BN000181 = 10000001, BN000391 = 10, BN000392 = 2.00F, BN000393 = "DIN 120",});
                _context.IdentChs.Add(new IdentCh { BN000035 = 100, BN000036 = "111", BN000071 = 1, BN000073 = 2, BN000181 = 10000001, BN000391 = 20, BN000392 = 2.22F, BN000393 = "ISO 4170", });
                _context.IdentChs.Add(new IdentCh { BN000035 = 100, BN000036 = "111", BN000071 = 1, BN000073 = 2, BN000181 = 10000001, BN000391 = 0, BN000392 = 2.03F, BN000393 = "", });
                _context.SaveChanges();
            }

        }
        // GET: api/IdentCh
        [HttpGet]
        public async Task<ActionResult<IEnumerable<IdentCh>>> GetIdentChs()
        {
            return await _context.IdentChs.ToListAsync();
        }

        // GET: api/IdentCh/5
        [HttpGet("{id}")]
        public async Task<ActionResult<IdentCh>> GetIdentCh(int id)
        {
            var identCh = await _context.IdentChs.FindAsync(id);

            if (identCh == null)
            {
                return NotFound();
            }

            return identCh;
        }

        /*
        // POST api/IdentCh
        [HttpPost]
        public async Task<ActionResult<IdentCh>> PostIdent(IdentCh identCh)
        {
            _context.IdentChs.Add(identCh);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetIdentCh", new { id = identCh.Id }, identCh);
        }

        // PUT api/IdentCh/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutIdentCh(long id, IdentCh identCh)
        {
            if (id != identCh.Id)
            {
                return BadRequest();
            }

            _context.Entry(identCh).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE api/IdentCh/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<IdentCh>> DeleteIdentCh(int id)
        {
            var identCh = await _context.IdentChs.FindAsync(id);
            if (identCh == null)
            {
                return NotFound();
            }

            _context.IdentChs.Remove(identCh);
            await _context.SaveChangesAsync();

            return identCh;
        }
*/
    }
}
