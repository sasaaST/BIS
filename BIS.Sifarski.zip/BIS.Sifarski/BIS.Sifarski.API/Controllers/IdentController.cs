﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BIS.Sifarski.Domain.Entities;
using BIS.Sifarski.Persistence;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BIS.Sifarski.API.Controllers
{
    [Route("api/[controller]")]
    public class IdentController : Controller
    {
        private readonly SifarskiDbContext _context;

        public IdentController(SifarskiDbContext context)
        {
            _context = context;

            if (_context.Idents.Count() == 0)
            {
                _context.Idents.Add(new Ident
                {
                    Id = 1,
                    BN000035 = 100,
                    BN000036 = "111",
                    BN000181 = 10000001,
                    BN000182 = 329649,
                    BN000183 = 20190101,
                    BN000184 = 0,
                    BN000185 = 0,
                    BN000250 = ' ',
                    BN000251 = ' ',
                    BN000379 = "test",
                    BN000252 = "KOM",
                    BN000260 = 0,
                    BN000380 = "test ident",
                    BN000243 = ".",
                    BN000388 = "test opis",
                    BN000576 = ' ',
                    BN000601 = ' ',
                    BN000639 = "329649",
                    BN000640 = "",
                    BND00089 = "N",
                    BN000749 = 0,
                    BN000750 = 0,
                    BN000002 = "329649",
                    BND00011 = 20190101,
                    BNDC0265 = 0,
                    BN001055 = 1,
                });
                _context.SaveChanges();
            }

        }
        // GET: api/Ident
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Ident>>> GetIdents()
        {
            return await _context.Idents.ToListAsync();
        }

        // GET api/Ident/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Ident>> GetIdent(int id)
        {
            var ident = await _context.Idents.FindAsync(id);

            if (ident == null)
            {
                return NotFound();
            }

            return ident;
        }

        // POST api/Ident
        [HttpPost]
        public async Task<ActionResult<Ident>> PostIdent(Ident ident)
        {
            _context.Idents.Add(ident);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetIdent", new { id = ident.Id }, ident);
        }

        // PUT api/Ident/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutIdent(long id, Ident ident)
        {
            if (id != ident.Id)
            {
                return BadRequest();
            }

            _context.Entry(ident).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE api/Ident/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Ident>> DeleteIdent(int id)
        {
            var ident = await _context.Idents.FindAsync(id);
            if (ident == null)
            {
                return NotFound();
            }

            _context.Idents.Remove(ident);
            await _context.SaveChangesAsync();

            return ident;
        }
    }
}
