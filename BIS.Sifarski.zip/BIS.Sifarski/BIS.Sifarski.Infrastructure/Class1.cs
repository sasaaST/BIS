﻿using System;

namespace BIS.Sifarski.Infrastructure
{
    public class Class1
    {
    }
}
